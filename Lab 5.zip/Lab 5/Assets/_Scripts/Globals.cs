﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Globals : MonoBehaviour {

	public const string MENU_SCENE = "menu";
	public const string GAME_SCENE = "game";

}
