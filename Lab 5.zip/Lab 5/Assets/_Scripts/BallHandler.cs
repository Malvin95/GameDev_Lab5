﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallHandler : MonoBehaviour {

	public GameObject ballPrefab;
	public UIHandler UI;
	
	// Update is called once per frame
	void Update () {
		FireBall ();
	}

	void FireBall()
	{
		/**
		If the UI ammoVal Value is larger than 0
		then the player is allowed to fire the ball.
		*/
		if (UI.getAmmoVal () > 0)
		{
			if(Input.GetMouseButtonDown(0))
			{
				//Calls the UIHandler Fire() method.
				UI.Fire();

				//The Ball object is declared and instantiated.
				GameObject clone;
				clone = Instantiate(ballPrefab, Camera.main.transform.position, Camera.main.transform.rotation);

				//The Rigid body component is called, assigned and has a force added to it. 
				Rigidbody rb = clone.GetComponent<Rigidbody>();
				rb.AddForce(clone.transform.forward * 20, ForceMode.Impulse);

				//The clone ball GameObject is destroyed after 10 seconds.
				Destroy (clone, 10);
			}
		}

	}
}
