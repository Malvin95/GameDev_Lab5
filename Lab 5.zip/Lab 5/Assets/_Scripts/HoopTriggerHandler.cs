﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HoopTriggerHandler : MonoBehaviour {

	public int Score;
	public UIHandler UI;

	void update()
	{
		OnTriggerEnter ();
	}

	void OnTriggerEnter(){
		float dist = Vector3.Distance (Camera.main.transform.position, transform.position);
		int val = Mathf.RoundToInt(dist);
		Score = val;
		UI.Scored (Score);
	}
}
