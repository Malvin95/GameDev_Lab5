﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHandler : MonoBehaviour {

	public Text Ammotext;
	public int ammoVal;

	public Text scoreText;
	public int score;

	public int getAmmoVal()
	{
		return ammoVal;
	}

	public void Fire()
	{
		ammoVal -= 1;
		Ammotext.text = string.Format("Ammo: " + ammoVal.ToString ());
	}

	public void Scored(int val)
	{
		score += val;
		scoreText.text = string.Format("Score: " + score.ToString ());
	}
}
